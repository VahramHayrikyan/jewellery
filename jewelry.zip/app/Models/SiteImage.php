<?php

namespace App\Models;

class SiteImage extends BaseModel
{
    protected $guarded = [];
}
