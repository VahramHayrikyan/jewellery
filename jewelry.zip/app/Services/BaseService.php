<?php

namespace App\Services;

use App\Traits\Response;

Class BaseService
{
    use Response;
}
