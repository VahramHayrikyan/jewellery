<?php

namespace Database\Seeders;

use App\Models\Cart;
use Illuminate\Database\Seeder;

class CartSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $carts = [];

        foreach (range(1,3) as $index) {
            array_push($carts, [
                'user_id' => $index,
            ]);
        }

        foreach ($carts as $cart) {
            Cart::create($cart);
        }
    }
}
